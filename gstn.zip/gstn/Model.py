
import subprocess
import sys

# List of packages to install
packages = ['xgboost', 'optuna', 'joblib', 'pandas', 'scikit-learn', 'tqdm']

# Install each package using pip
for package in packages:
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
import xgboost as xgb
import optuna
from tqdm import tqdm
import joblib

# Load the data
print("Loading data...")
X_train = pd.read_csv('X_Train_Data_Input.csv')
Y_train = pd.read_csv('Y_Train_Data_Target.csv')
X_test = pd.read_csv('X_Test_Data_Input.csv')
Y_test = pd.read_csv('Y_Test_Data_Target.csv')

# Merge the target variable with the training data
train_data = X_train.merge(Y_train, on='ID')

# Drop the ID column
train_data.drop('ID', axis=1, inplace=True)
X_test_ids = X_test['ID']
X_test.drop('ID', axis=1, inplace=True)

# Handle missing values
print("Handling missing values...")
train_data.fillna(train_data.median(), inplace=True)
X_test.fillna(X_test.median(), inplace=True)

# Separate features and target variable
X = train_data.drop('target', axis=1)
y = train_data['target']

# Feature selection
print("Performing feature selection...")
selector = SelectKBest(score_func=f_classif, k='all')  # Select top 50 features
X_selected = selector.fit_transform(X, y)
X_test_selected = selector.transform(X_test)

# Normalize/standardize the data
print("Normalizing data...")
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_selected)
X_test_scaled = scaler.transform(X_test_selected)

# Define the objective function for Optuna
def objective(trial):
    params = {
        'max_depth': trial.suggest_int('max_depth', 3, 10),
        'learning_rate': trial.suggest_loguniform('learning_rate', 1e-3, 0.1),
        'n_estimators': trial.suggest_int('n_estimators', 100, 1000),
        'min_child_weight': trial.suggest_int('min_child_weight', 1, 10),
        'subsample': trial.suggest_uniform('subsample', 0.6, 1.0),
        'colsample_bytree': trial.suggest_uniform('colsample_bytree', 0.6, 1.0),
    }

    model = xgb.XGBClassifier(**params, random_state=42, use_label_encoder=False, eval_metric='logloss')
    return np.mean(cross_val_score(model, X_scaled, y, cv=3, scoring='roc_auc'))

# Hyperparameter tuning with Optuna
print("Starting hyperparameter tuning with Optuna...")
study = optuna.create_study(direction='maximize')
study.optimize(objective, n_trials=50, show_progress_bar=True)

best_params = study.best_params
print("Best parameters:", best_params)

# Train the final model
print("Training the final model...")
final_model = xgb.XGBClassifier(**best_params, random_state=42, use_label_encoder=False, eval_metric='logloss')

# Fit the model without early stopping
final_model.fit(X_scaled, y)

# Evaluate the model on training data
print("Evaluating the model on training data...")
y_train_pred = final_model.predict(X_scaled)
y_train_pred_proba = final_model.predict_proba(X_scaled)[:, 1]

train_accuracy = accuracy_score(y, y_train_pred)
train_precision = precision_score(y, y_train_pred)
train_recall = recall_score(y, y_train_pred)
train_f1 = f1_score(y, y_train_pred)
train_roc_auc = roc_auc_score(y, y_train_pred_proba)
train_conf_matrix = confusion_matrix(y, y_train_pred)

print("Training Set Metrics:")
print(f'Accuracy: {train_accuracy:.4f}')
print(f'Precision: {train_precision:.4f}')
print(f'Recall: {train_recall:.4f}')
print(f'F1 Score: {train_f1:.4f}')
print(f'ROC AUC: {train_roc_auc:.4f}')
print(f'Confusion Matrix:\n{train_conf_matrix}')

# Evaluate the model on test data
print("Evaluating the model on test data...")
y_test_pred = final_model.predict(X_test_scaled)
y_test_pred_proba = final_model.predict_proba(X_test_scaled)[:, 1]

test_accuracy = accuracy_score(Y_test['target'], y_test_pred)
test_precision = precision_score(Y_test['target'], y_test_pred)
test_recall = recall_score(Y_test['target'], y_test_pred)
test_f1 = f1_score(Y_test['target'], y_test_pred)
test_roc_auc = roc_auc_score(Y_test['target'], y_test_pred_proba)
test_conf_matrix = confusion_matrix(Y_test['target'], y_test_pred)

print("Test Set Metrics:")
print(f'Accuracy: {test_accuracy:.4f}')
print(f'Precision: {test_precision:.4f}')
print(f'Recall: {test_recall:.4f}')
print(f'F1 Score: {test_f1:.4f}')
print(f'ROC AUC: {test_roc_auc:.4f}')
print(f'Confusion Matrix:\n{test_conf_matrix}')

# Generate predictions on the test data
print("Generating predictions on test data...")
y_test_pred_final = final_model.predict(X_test_scaled)

# Prepare the submission file
submission = pd.DataFrame({'ID': X_test_ids, 'target': y_test_pred_final})
submission.to_csv('submission.csv', index=False)

print("Submission file created: submission_1.csv")

# Save the Model
joblib.dump(final_model, 'final_model.pkl')
print("Model saved as final_model.pkl")
