import joblib
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_classif

# Load the model
final_model = joblib.load('final_model.pkl')

# Load the validation data (assuming it's provided as 'X_Val_Data_Input.csv')
X_val_data = pd.read_csv('X_Val_Data_Input.csv')
X_val_ids = X_val_data['ID']
X_val_data.drop('ID', axis=1, inplace=True)

# Preprocess the validation data (similar to training data preprocessing)
X_val_data.fillna(X_val_data.median(), inplace=True)

# Assuming the same feature selection and scaling as in the training script
selector = SelectKBest(score_func=f_classif, k='all') 
X_val_selected = selector.fit_transform(X_val_data, X_val_data) 
scaler = StandardScaler()
X_val_scaled = scaler.fit_transform(X_val_selected) 

# Generate predictions on the validation data
y_val_pred = final_model.predict(X_val_scaled)

# Prepare the submission file for validation data
val_submission = pd.DataFrame({'ID': X_val_ids, 'target': y_val_pred})
val_submission.to_csv('val_submission.csv', index=False)

print("Validation submission file created: val_submission.csv")
