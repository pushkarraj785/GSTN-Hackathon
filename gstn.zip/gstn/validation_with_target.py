import joblib
import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_classif

# Load the model
final_model = joblib.load('final_model.pkl')

# Load the validation data (assuming it's provided as 'X_Val_Data_Input.csv' and 'Y_Val_Data_Target.csv')
X_val_data = pd.read_csv('X_Val_Data_Input.csv')
Y_val_data = pd.read_csv('Y_Val_Data_Target.csv')
X_val_ids = X_val_data['ID']
X_val_data.drop('ID', axis=1, inplace=True)

# Preprocess the validation data (similar to training data preprocessing)
X_val_data.fillna(X_val_data.median(), inplace=True)

# Assuming the same feature selection and scaling as in the training script
selector = SelectKBest(score_func=f_classif, k='all')  
X_val_selected = selector.fit_transform(X_val_data, Y_val_data['target'])  
scaler = StandardScaler()
X_val_scaled = scaler.fit_transform(X_val_selected) 

# Generate predictions on the validation data
y_val_pred = final_model.predict(X_val_scaled)
y_val_pred_proba = final_model.predict_proba(X_val_scaled)[:, 1]

# Calculate performance metrics
val_accuracy = accuracy_score(Y_val_data['target'], y_val_pred)
val_precision = precision_score(Y_val_data['target'], y_val_pred)
val_recall = recall_score(Y_val_data['target'], y_val_pred)
val_f1 = f1_score(Y_val_data['target'], y_val_pred)
val_roc_auc = roc_auc_score(Y_val_data['target'], y_val_pred_proba)
val_conf_matrix = confusion_matrix(Y_val_data['target'], y_val_pred)

print("Validation Set Metrics:")
print(f'Accuracy: {val_accuracy:.4f}')
print(f'Precision: {val_precision:.4f}')
print(f'Recall: {val_recall:.4f}')
print(f'F1 Score: {val_f1:.4f}')
print(f'ROC AUC: {val_roc_auc:.4f}')
print(f'Confusion Matrix:\n{val_conf_matrix}')

# Prepare the submission file for validation data
val_submission = pd.DataFrame({'ID': X_val_ids, 'target': y_val_pred})
val_submission.to_csv('val_submission_2.csv', index=False)

print("Validation submission file with metrics created: val_submission_2.csv")
